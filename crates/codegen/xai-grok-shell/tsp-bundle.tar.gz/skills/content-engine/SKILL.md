---
name: content-engine
description: Create platform-native content systems for X, LinkedIn, TikTok, YouTube, newsletters, and repurposed multi-platform campaigns. Use when the user wants social posts, threads, scripts, content calendars, or one source asset adapted cleanly across platforms.
origin: ECC
tsp_source: skills/content-engine/SKILL.md
tsp_version: 2.5.6
adapter_version: 0.1.0
generated_at: "2026-08-03T00:07:28.217Z"
---

# Content Engine

Build platform-native content without flattening the author's real voice into platform slop.

## When to Activate

- writing X posts or threads
- drafting LinkedIn posts or launch updates
- scripting short-form video or YouTube explainers
- repurposing articles, podcasts, demos, docs, or internal notes into public content
- building a launch sequence or ongoing content system around a product, insight, or narrative

## Non-Negotiables

1. Start from source material, not generic post formulas.
2. Adapt the format for the platform, not the persona.
3. One post should carry one actual claim.
4. Specificity beats adjectives.
5. No engagement bait unless the user explicitly asks for it.

## Source-First Workflow

Before drafting, identify the source set:
- published articles
- notes or internal memos
- product demos
- docs or changelogs
- transcripts
- screenshots
- prior posts from the same author

If the user wants a specific voice, build a voice profile from real examples before writing.
Use `brand-voice` as the canonical workflow when voice consistency matters across more than one output.

## Voice Capture Workflow

Run `brand-voice` first when:

- there are multiple downstream outputs
- the user explicitly cares about writing style
- the content is launch, outreach, or reputation-sensitive

At minimum, produce a compact `VOICE PROFILE` covering:
- rhythm
- compression
- capitalization
- parenthetical use
- question use
- preferred moves
- banned moves

Do not start drafting until the voice profile is clear enough to enforce.

## Affaan / ECC Voice Reference

When the user wants Affaan / ECC voice specifically, default to this unless newer examples clearly override it:
- direct, compressed, concrete
- strong preference for specific claims, numbers, mechanisms, and receipts
- parentheticals used to qualify, narrow, or over-clarify, not to do corny bits
- lowercase is optional, not mandatory
- questions are rare and should not be added as bait
- transitions should feel earned, not polished
- tone can be sharp or blunt, but should not sound like a content marketer

## Hard Bans

Delete and rewrite any of these:
- "In today's rapidly evolving landscape"
- "game-changer", "revolutionary", "cutting-edge"
- "no fluff"
- "not X, just Y"
- "here's why this matters" unless it is followed immediately by something concrete
- "Excited to share"
- fake curiosity gaps
- ending with a LinkedIn-style question just to farm replies
- forced lowercase when the source voice does not call for it
- forced casualness on LinkedIn
- parenthetical jokes that were not present in the source voice

## Platform Adaptation Rules

### X

- open with the strongest claim, artifact, or tension
- keep the compression if the source voice is compressed
- if writing a thread, each post must advance the argument
- do not pad with context the audience does not need

### LinkedIn

- expand only enough for people outside the immediate niche to follow
- do not turn it into a fake lesson post unless the source material actually is reflective
- no corporate inspiration cadence
- no praise-stacking, no "journey" filler

### Short Video

- script around the visual sequence and proof points
- first seconds should show the result, problem, or punch
- do not write narration that sounds better on paper than on screen

### YouTube

- show the result or tension early
- organize by argument or progression, not filler sections
- use chaptering only when it helps clarity

### Newsletter

- open with the point, conflict, or artifact
- do not spend the first paragraph warming up
- every section needs to add something new

## Repurposing Flow

1. Pick the anchor asset.
2. Extract 3 to 7 atomic claims or scenes.
3. Rank them by sharpness, novelty, and proof.
4. Assign one strong idea per output.
5. Adapt structure for each platform.
6. Strip platform-shaped filler.
7. Run the quality gate.

## Deliverables

When asked for a campaign, return:
- a short voice profile if voice matching matters
- the core angle
- platform-native drafts
- posting order only if it helps execution
- gaps that must be filled before publishing

## Quality Gate

Before delivering:
- every draft sounds like the intended author, not the platform stereotype
- every draft contains a real claim, proof point, or concrete observation
- no generic hype language remains
- no fake engagement bait remains
- no duplicated copy across platforms unless requested
- any CTA is earned and user-approved

## Related Skills

- `brand-voice` for source-derived voice profiles
- `crosspost` for platform-specific distribution
- `x-api` for sourcing recent posts and publishing approved X output
