---
tsp_source: commands/goal.md
tsp_version: 2.5.6
adapter_version: 0.1.0
generated_at: "2026-08-03T00:07:28.217Z"
---
# /goal

> 本文件由 `scripts/build-platform-artifacts.js` 生成，请勿手改。

## 用途

管理循环任务的目标状态和收敛条件。

## 主责角色

- `loop-engineer`

## 期望输入



## 标准输出



输出字段定义与交付结构见 [team-command-output-contracts.md](../docs/runbooks/team-command-output-contracts.md)。

## 默认流程

1. 管理循环任务的目标状态。
2. 更新收敛条件和优先级。
3. 检查目标是否已达成。
