---
tsp_source: commands/quick.md
tsp_version: 2.5.6
adapter_version: 0.1.0
generated_at: "2026-08-03T00:07:28.217Z"
---
# /quick

## 用途

快速执行模式入口。对边界清晰、影响面小、无跨团队依赖的小型任务，跳过完整 `/team-*` 链路直接执行。

## 主责角色

- 当前执行角色（通常为 `frontend-engineer` 或 `backend-engineer`）

## 期望输入

- 一句话任务描述
- 可选：相关文件路径或上下文

## 标准输出

- 代码改动（含测试）
- conventional commit（带 `[quick]` 标记）
- 若降级：降级说明 + 建议切换的标准命令

## 默认流程

1. 加载 `skills/quick-execution` 技能。
2. 验证是否满足快速模式准入条件：
   - 范围明确（一句话可描述）
   - 影响面小（≤3 文件 / ≤100 行）
   - 无跨团队依赖
   - 可独立回滚
   - 风险低（非鉴权/支付/数据迁移/API 契约变更）
3. 若准入通过，直接执行：编码 → 自测 → 内联验证 → 提交。
4. 若准入不通过或执行中发现超出范围，自动降级到 `/team-intake` 或 `/team-plan`。
5. 提交使用 conventional commit 格式，message 中注明 `[quick]`。
