---
tsp_source: commands/resume.md
tsp_version: 2.5.6
adapter_version: 0.1.0
generated_at: "2026-08-03T00:07:28.217Z"
---
# /resume

## 用途

恢复之前通过 `/pause` 暂停的工作会话，从状态快照中恢复上下文并继续执行。

## 主责角色

- 当前执行角色

## 期望输入

- 可选：指定恢复的状态文件路径（默认取最近的 `paused` 状态文件）

## 标准输出

- 恢复的上下文摘要
- 接续的 todo list
- 下一步行动建议

## 默认流程

1. 加载 `skills/session-continuity` 技能。
2. 在 `docs/memory/sessions/` 下查找最新的 `status: paused` 状态文件。
3. 读取并输出恢复上下文摘要：
   - 之前在做什么
   - 已完成和未完成的项目
   - 关键决策和阻塞项
4. 按恢复指令执行初始化步骤。
5. 将状态文件标记为 `active`。
6. 从"进行中项"继续执行。
