---
description: Legacy slash-entry shim for the rules-distill skill. Prefer the skill directly.
tsp_source: commands/rules-distill.md
tsp_version: 2.5.6
adapter_version: 0.1.0
generated_at: "2026-08-03T00:07:28.217Z"
---

# Rules Distill (Legacy Shim)

Use this only if you still invoke `/rules-distill`. The maintained workflow lives in `skills/rules-distill/SKILL.md`.

## Canonical Surface

- Prefer the `rules-distill` skill directly.
- Keep this file only as a compatibility entry point.

## Arguments

`$ARGUMENTS`

## Delegation

Apply the `rules-distill` skill and follow its inventory, cross-read, and verdict workflow instead of duplicating that logic here.
